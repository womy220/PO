#include "Calculator.h"
#include <math.h>
#include <iostream>
#include <string>


using namespace std;

int main()
{
	int option;
	double x, y, a, b, c, x1, x2;

	Calculator calc;

	cout << "Choose one option " << endl;
	cout << "1.Add" << endl << "2.Subtract" << endl << "3.Multiply" << endl << "4.Divide" << endl << "5.Square function roots" << endl;
	cin >> option;

	if (option > 0 && option <= 5)
	{
		if (option != 5)
		{
			cout << "Give me x and y" << endl;
			cin >> x >> y;
			switch (option)
			{
			case 1:
			{
				calc.add(x, y);
				cout << calc.get_result() << endl;
				break;
			}
			case 2:
			{
				calc.subtract(x, y);
				cout << calc.get_result() << endl;
				break;

			}
			case 3:
			{
				calc.multiply(x, y);
				cout << calc.get_result() << endl;

				break;
			}
			case 4:
			{
				Calculator::Status error = calc.divide(x, y);
				cout << "Status: " << Calculator::ToString(error) << endl;
				if (y != 0) {
					cout << calc.get_result() << endl;
				}

				break;
			}
			}
		}
		else
		{
			cout << "Give me a, b, c" << endl;
			cin >> a >> b >> c;
			Calculator::Status error2 = calc.square_function_roots(a, b, c, x1, x2);
			cout << "Status: " << Calculator::ToString(error2) << endl;
			if (error2 == Calculator::Status::TwoRoots) {
				cout << "x1=" << x1 << endl;
				cout << "x2=" << x2 << endl;	
			}
			else if (error2 == Calculator::Status::OneRoot) {
				cout << "x0=" << x1 << endl;
			}
		}
	}
	else
		cout << "wrong date";

	return 0;
}