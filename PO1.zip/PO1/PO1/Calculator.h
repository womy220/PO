#pragma once

class Calculator {
private:
    double result = 0.0;
public:
    enum class Status {
        Success,
        DivisionByZero,
        TwoRoots,
        OneRoot,
        NoRoots,
        InvalidParameter
      
    };
    inline static const char* ToString(Status v)            //zamiana enuma na stringa �eby si� da�o p�niej wypisa�
    {
        switch (v)
        {
        case Status::TwoRoots:   return "Two roots";
        case Status::OneRoot:   return "One root";
        case Status::NoRoots:  return "No roots";
        case Status::DivisionByZero: return "Division by zero";
        case Status::Success: return "Success";
        default:      return "[Unknown Status]";
        }
    }
    Calculator();
    ~Calculator();

    void add(double x, double y);
    void subtract(double x, double y);
    void multiply(double x, double y);
    Status divide(double x, double y);
    double get_result();
    Status square_function_roots(
        double a, double b, double c,
        double& x1, double& x2
    );
};