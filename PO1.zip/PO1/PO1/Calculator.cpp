#include "Calculator.h"
#include <cmath>

Calculator::Calculator() {}

Calculator::~Calculator() {}

void Calculator::add(double x, double y) {
    result = x + y;
}

void Calculator::subtract(double x, double y) {
    result = x - y;
}

void Calculator::multiply(double x, double y) {
    result = x * y;
}

Calculator::Status Calculator::divide(double x, double y) {
    if (y == 0.0) {
        return Calculator::Status::DivisionByZero;
    }
    result = x / y;
    return Calculator::Status::Success;
}

double Calculator::get_result() {
    return result;
}

Calculator::Status Calculator::square_function_roots(
    double a, double b, double c,
    double& x1, double& x2
) {
    double delta;
    delta = b * b - 4 * a * c;
    double pd = sqrt(delta);
    if (a == 0) {
        return Calculator::Status::InvalidParameter;
    }
    else if (delta > 0)
    {
        x1 = (-pd - b) / (2 * a);
        x2 - (-pd + b) / (2 * a);
        return Calculator::Status::TwoRoots;
    }
    else if (delta == 0)
    {
        x1 = -b / (2 * a);
        return Calculator::Status::OneRoot;
    }
    else if (delta < 0)
    {
        return Calculator::Status::NoRoots;
    }
}
